package com.sam.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CompletableDeferred

/**
 * OPT-IN. Acts only inside WhatsApp, only within seconds after SAM itself opened a pre-filled chat, and only taps "Send".
 * It never reads chats and never bypasses anything.
 */
class SamAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: SamAccessibilityService? = null
        @Volatile var armedUntil = 0L
        @Volatile var pending: CompletableDeferred<Boolean>? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val d = pending ?: return
        if (System.currentTimeMillis() > armedUntil) return
        if (e?.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val root = rootInActiveWindow ?: return
        val send = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull() ?: findByDesc(root)
        if (send != null && send.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { armedUntil = 0; pending = null; d.complete(true) }
    }

    private fun findByDesc(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val d = n.contentDescription?.toString()
        if (d != null && (d.equals("Send", true) || d == "भेजें") && n.isClickable) return n
        for (i in 0 until n.childCount) { n.getChild(i)?.let { c -> findByDesc(c)?.let { return it } } }
        return null
    }
}
