package com.sam.assistant.ui

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sam.assistant.ai.*
import com.sam.assistant.brain.Brain
import com.sam.assistant.brain.RuleBasedBrain
import com.sam.assistant.core.*
import com.sam.assistant.data.Prefs
import com.sam.assistant.service.SamService
import com.sam.assistant.tools.*
import com.sam.assistant.voice.VoiceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

enum class SamState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, ERROR }
data class Msg(val fromUser: Boolean, val text: String)

class SamViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val messages = mutableStateListOf(Msg(false, "Ji Sir? Mic dabayein ya type karein."))
    var state by mutableStateOf(SamState.IDLE); private set
    var permRequest by mutableStateOf<String?>(null); private set
    var attachment by mutableStateOf<Attachment?>(null); private set
    private var lastText = ""
    private val history = mutableListOf<Pair<String, String>>()
    private val brain: Brain = RuleBasedBrain()
    private val client = GeminiClient(prefs)
    private val agent = GeminiAgent(prefs, client)
    private lateinit var registry: ToolRegistry

    init {
        registry = ToolRegistry(listOf(OpenAppTool(app), SetTimerTool(app), SetAlarmTool(app),
            BatteryTool(app), TimeTool(), DeviceInfoTool(), OpenSettingsTool(app), ConnectivityTool(app), WebSearchTool(app),
            VolumeTool(app), BrightnessTool(app), DndTool(app),
            CallTool(app), SmsTool(app), CalendarReadTool(app), CalendarCreateTool(app), WeatherTool(app), SetCityTool(app),
            RememberTool(prefs), CreateRoutineTool(prefs), RunRoutineTool(prefs) { registry.run(it) }, WebAnswerTool(prefs, client)),
            isLocked = { (app.getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked })
    }

    var wakeSession = false
    private val voice = VoiceEngine(app, { submit(it) },
        { msg -> if (wakeSession) { wakeSession = false; state = SamState.IDLE; SamService.resumeWake() } else reply(msg, SamState.ERROR) }, // woken by "SAM" but no command -> quietly back to standby
        { wakeSession = false; state = SamState.IDLE; SamService.resumeWake() })

    fun listen() { SamService.pauseWake(90000); voice.stop(); state = SamState.LISTENING; voice.startListening(prefs.lang) }
    fun clearPerm() { permRequest = null }
    fun permissionDenied(msg: String = "Sir, mic permission ke bina main sun nahi sakta. Aap type kar sakte hain.") = reply(msg, SamState.ERROR)
    fun submit(text: String) { SamService.pauseWake(90000); messages += Msg(true, text); run(text) }
    fun retry() = run(lastText)
    fun dropAttachment() { attachment = null }

    fun attach(uri: Uri) {
        viewModelScope.launch {
            val cr = getApplication<Application>().contentResolver
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val bytes = withContext(Dispatchers.IO) { try { cr.openInputStream(uri)?.use { it.readBytes() } } catch (e: Exception) { null } }
            when {
                bytes == null -> reply("Sir, file padh nahi paya.", SamState.ERROR)
                bytes.size > 15_000_000 -> reply("Sir, file bahut badi hai (15MB tak).", SamState.ERROR)
                !(mime.startsWith("image/") || mime == "application/pdf" || mime.startsWith("text/")) ->
                    reply("Sir, abhi sirf image, PDF aur text file samajh sakta hoon.", SamState.ERROR)
                else -> attachment = Attachment(uri.lastPathSegment ?: "file", mime, withContext(Dispatchers.IO) { Base64.encodeToString(bytes, Base64.NO_WRAP) })
            }
        }
    }

    private suspend fun exec(c: ToolCall): ToolResult {
        state = SamState.EXECUTING
        val r = registry.run(c)
        if (r.permission != null) permRequest = r.permission
        return r
    }

    private fun run(text: String) {
        lastText = text; state = SamState.THINKING
        viewModelScope.launch {
            val routine = prefs.routines().keys.firstOrNull { text.lowercase().contains(it) }
            if (routine != null) { val r = exec(ToolCall("run_routine", mapOf("name" to routine))); reply((if (r.status == Status.SUCCESS) "Done Sir.\n" else "") + r.message); return@launch }
            var note = ""
            if (prefs.apiKey.isNotBlank()) {
                try {
                    val att = attachment
                    val out = agent.run(text, att, history.takeLast(16)) { exec(it) }
                    attachment = null
                    history += "user" to text; history += "model" to out
                    reply(out); return@launch
                } catch (e: GeminiException) {
                    note = when (e.code) {
                        400, 401, 403 -> "Sir, Gemini API key ya model sahi nahi lagta."
                        404 -> "Sir, ye Gemini model nahi mila, settings mein model badlein."
                        429 -> "Sir, Gemini ki limit khatam ho gayi, thodi der baad try karein."
                        else -> "Sir, Gemini ne error diya."
                    } + " [${e.code}: ${e.message?.replace("\n", " ")?.take(180)}] Basic mode use kar raha hoon.\n"
                } catch (e: IOException) { note = "Sir, internet nahi hai, basic mode use kar raha hoon.\n" }
            }
            val plan = brain.plan(text)
            if (plan.calls.isEmpty()) { reply(note + (plan.directReply ?: ""), tag = if (plan.english) "en-IN" else null); return@launch }
            val results = plan.calls.map { it to exec(it.copy()) }
            reply(note + brain.summarize(plan, results), tag = if (plan.english) "en-IN" else null)
        }
    }

    private fun looksEnglish(t: String) = Regex("\\b(the|is|you|your|and|with)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) &&
        !Regex("\\b(hai|hain|karo|kar|nahi|aap|mein)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)

    private fun reply(t: String, s: SamState = SamState.SPEAKING, tag: String? = null) {
        messages += Msg(false, t); state = s
        if (s != SamState.SPEAKING) SamService.resumeWake()
        if (s == SamState.SPEAKING) voice.speak(t, tag ?: if (looksEnglish(t)) "en-IN" else prefs.lang)
    }
    override fun onCleared() { voice.release() }
}
