package com.sam.assistant.ui

import android.app.Application
import android.net.Uri
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sam.assistant.Graph
import com.sam.assistant.ai.*
import com.sam.assistant.brain.Brain
import com.sam.assistant.brain.RuleBasedBrain
import com.sam.assistant.core.*
import com.sam.assistant.data.Prefs
import com.sam.assistant.service.SamService
import com.sam.assistant.voice.VoiceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

enum class SamState { IDLE, LISTENING, THINKING, EXECUTING, SPEAKING, ERROR }
data class Msg(val fromUser: Boolean, val text: String)

class SamViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val messages = mutableStateListOf(Msg(false, "Ji Sir? Mic dabayein ya type karein."))
    var state by mutableStateOf(SamState.IDLE); private set
    var permRequest by mutableStateOf<String?>(null); private set
    var attachment by mutableStateOf<Attachment?>(null); private set
    var level by mutableStateOf(0f); private set      // live mic loudness 0..1
    var partial by mutableStateOf(""); private set    // live words heard
    var progress by mutableStateOf(""); private set   // long-task progress
    var wakeSession = false
    private var lastText = ""
    private var step = 0
    private var total = 0
    private var pendingConfirm: ToolCall? = null
    private val history = mutableListOf<Pair<String, String>>()
    private val brain: Brain = RuleBasedBrain()
    private val client = GeminiClient(prefs)
    private val agent = GeminiAgent(prefs, client)
    private val registry = Graph.registry(app)

    private val voice = VoiceEngine(app, { prefs.speed },
        { partial = ""; submit(it) },
        { msg -> level = 0f; partial = ""
            if (wakeSession) { wakeSession = false; state = SamState.IDLE; SamService.resumeWake() } // woken by "SAM" but no command -> standby
            else reply(msg, SamState.ERROR) },
        { wakeSession = false; state = SamState.IDLE; SamService.resumeWake() },
        { level = it }, { partial = it })

    fun listen() { SamService.pauseWake(90000); voice.stop(); partial = ""; state = SamState.LISTENING; voice.startListening(prefs.lang) }
    fun clearPerm() { permRequest = null }
    fun permissionDenied(msg: String = "Sir, mic permission ke bina main sun nahi sakta. Aap type kar sakte hain.") = reply(msg, SamState.ERROR)
    fun submit(text: String) { SamService.pauseWake(90000); messages += Msg(true, text); run(text) }
    fun retry() = run(lastText)
    fun dropAttachment() { attachment = null }

    fun attach(uri: Uri) {
        viewModelScope.launch {
            val cr = getApplication<Application>().contentResolver
            val mime = cr.getType(uri) ?: "application/octet-stream"
            val bytes = withContext(Dispatchers.IO) { try { cr.openInputStream(uri)?.use { it.readBytes() } } catch (e: Exception) { null } }
            when {
                bytes == null -> reply("Sir, file padh nahi paya.", SamState.ERROR)
                bytes.size > 15_000_000 -> reply("Sir, file bahut badi hai (15MB tak).", SamState.ERROR)
                !(mime.startsWith("image/") || mime == "application/pdf" || mime.startsWith("text/")) ->
                    reply("Sir, abhi sirf image, PDF aur text file samajh sakta hoon.", SamState.ERROR)
                else -> attachment = Attachment(uri.lastPathSegment ?: "file", mime, withContext(Dispatchers.IO) { Base64.encodeToString(bytes, Base64.NO_WRAP) })
            }
        }
    }

    private suspend fun exec(c: ToolCall): ToolResult {
        state = SamState.EXECUTING; step++
        progress = if (total > 0) "$step/$total ${c.name.replace('_', ' ')}" else "Step $step: ${c.name.replace('_', ' ')}"
        val r = registry.run(c)
        if (r.permission != null) permRequest = r.permission
        if (c.name == "send_whatsapp" && r.status == Status.USER_CONFIRMATION_REQUIRED && r.message.contains("bhej doon"))
            pendingConfirm = c.copy(args = c.args + ("confirmed" to "yes"))
        return r
    }

    private fun run(text: String) {
        lastText = text; state = SamState.THINKING; step = 0; total = 0; progress = ""
        viewModelScope.launch {
            pendingConfirm?.let { pc ->   // answer to "...bhej doon?"
                pendingConfirm = null
                if (Regex("(?i)\\b(nahi|nahin|no|mat|cancel|ruko)\\b").containsMatchIn(text)) { reply("Theek hai Sir, nahi bheja."); return@launch }
                if (Regex("(?i)\\b(haan|han|ha|yes|yeah|ok|okay|sure|kar do|bhej do|bhejo)\\b").containsMatchIn(text)) { reply(exec(pc).message); return@launch }
            }
            val routine = prefs.routines().keys.firstOrNull { text.lowercase().contains(it) }
            if (routine != null) { val r = exec(ToolCall("run_routine", mapOf("name" to routine))); reply((if (r.status == Status.SUCCESS) "Done Sir.\n" else "") + r.message); return@launch }
            var note = ""
            if (prefs.apiKey.isNotBlank()) {
                try {
                    val att = attachment
                    val out = agent.run(text, att, history.takeLast(16)) { exec(it) }
                    attachment = null
                    if (!prefs.privacyMode) { history += "user" to text; history += "model" to out }
                    reply(out); return@launch
                } catch (e: GeminiException) {
                    note = when (e.code) {
                        400, 401, 403 -> "Sir, Gemini API key ya model sahi nahi lagta."
                        404 -> "Sir, ye Gemini model nahi mila, settings mein model badlein."
                        429 -> "Sir, Gemini ki limit khatam ho gayi, thodi der baad try karein."
                        else -> "Sir, Gemini ne error diya."
                    } + " [${e.code}: ${e.message?.replace("\n", " ")?.take(180)}] Basic mode use kar raha hoon.\n"
                } catch (e: IOException) { note = "Sir, internet nahi hai, basic mode use kar raha hoon.\n" }
                step = 0
            }
            val plan = brain.plan(text)
            val tag = if (plan.english) "en-IN" else null
            if (plan.calls.isEmpty()) { reply(note + (plan.directReply ?: ""), tag = tag); return@launch }
            total = plan.calls.size
            val results = plan.calls.map { it to exec(it) }
            reply(note + brain.summarize(plan, results), tag = tag)
        }
    }

    private fun looksEnglish(t: String) = Regex("\\b(the|is|you|your|and|with)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) &&
        !Regex("\\b(hai|hain|karo|kar|nahi|aap|mein)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)

    private fun reply(t: String, s: SamState = SamState.SPEAKING, tag: String? = null) {
        progress = ""; level = 0f; partial = ""; total = 0
        if (prefs.historyOn && !prefs.privacyMode && lastText.isNotBlank()) prefs.addHistory("$lastText → ${t.replace("\n", " ").take(140)}")
        messages += Msg(false, t); state = s
        if (s != SamState.SPEAKING) SamService.resumeWake()
        if (s == SamState.SPEAKING) voice.speak(t, tag ?: if (looksEnglish(t)) "en-IN" else prefs.lang)
    }
    override fun onCleared() { voice.release() }
}
