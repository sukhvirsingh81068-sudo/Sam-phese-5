package com.sam.assistant.ai

import com.sam.assistant.core.*
import com.sam.assistant.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date

class GeminiException(val code: Int, msg: String) : IOException(msg)
class Attachment(val name: String, val mime: String, val b64: String)

/** Provider adapter: swap this class (and GeminiAgent) to change AI provider; UI and tools stay the same. */
class GeminiClient(private val prefs: Prefs) {
    fun generate(body: JSONObject): JSONObject {
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/${prefs.model}:generateContent").openConnection() as HttpURLConnection
        try {
            con.requestMethod = "POST"; con.doOutput = true
            con.connectTimeout = 15000; con.readTimeout = 60000
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("x-goog-api-key", prefs.apiKey)
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = con.responseCode
            val txt = (if (code < 400) con.inputStream else con.errorStream).bufferedReader().readText()
            if (code >= 400) throw GeminiException(code, txt.take(200))
            return JSONObject(txt)
        } finally { con.disconnect() }
    }
}

private val SPECS = listOf(
    Triple("open_app", "Open an installed app by name", mapOf("app" to "App name, e.g. youtube")),
    Triple("set_timer", "Start a countdown timer", mapOf("seconds" to "Duration in seconds")),
    Triple("set_alarm", "Set an alarm or a reminder (reminder = alarm with a message label). Sets next occurrence of that time.",
        mapOf("hour" to "0-23", "minute" to "0-59", "message" to "Optional label/reminder text")),
    Triple("get_battery_status", "Battery percent and charging state", emptyMap<String, String>()),
    Triple("get_time", "Current time", emptyMap<String, String>()),
    Triple("get_device_info", "Phone model and Android version", emptyMap<String, String>()),
    Triple("open_settings", "Open a settings screen", mapOf("section" to "wifi, bluetooth, display, sound or main")),
    Triple("toggle_connectivity", "Turn Wi-Fi/Bluetooth on or off. Android usually blocks direct toggling; the tool reports what it did.",
        mapOf("what" to "wifi or bluetooth", "state" to "on or off")),
    Triple("search_web", "Open a Google search in the browser", mapOf("query" to "Search text")),
    Triple("control_volume", "Set or change volume", mapOf("type" to "media, alarm, ring or notification",
        "level" to "0-100 percent (optional)", "delta" to "+1 or -1 for louder/quieter (optional)")),
    Triple("set_brightness", "Set or change screen brightness", mapOf("level" to "1-100 percent (optional)", "delta" to "+1 or -1 (optional)")),
    Triple("set_dnd", "Turn Do Not Disturb on/off", mapOf("state" to "on or off")),
    Triple("make_call", "Open dialer for a contact or number (user presses call)", mapOf("contact" to "Contact name", "number" to "Phone number")),
    Triple("send_message", "Prepare an SMS draft for a contact (user presses send)", mapOf("contact" to "Contact name", "text" to "Message text")),
    Triple("get_calendar_events", "List calendar events for a day", mapOf("day" to "0 = today, 1 = tomorrow")),
    Triple("create_calendar_event", "Open a pre-filled calendar event form", mapOf("title" to "Event title", "hour" to "0-23",
        "minute" to "0-59", "day" to "0 = today, 1 = tomorrow")),
    Triple("get_weather", "Real weather for today or tomorrow", mapOf("city" to "City (optional if saved)", "day" to "0 or 1")),
    Triple("set_city", "Save the user's home city", mapOf("city" to "City")),
    Triple("remember", "Save a useful, non-sensitive user preference/fact to memory", mapOf("fact" to "Short fact")),
    Triple("create_routine", "Save a custom command/routine. steps is a JSON array like [{\"tool\":\"set_dnd\",\"args\":{\"state\":\"on\"}}]",
        mapOf("name" to "Routine name, e.g. study mode", "steps" to "JSON array string of {tool,args}")),
    Triple("run_routine", "Run a saved routine by name", mapOf("name" to "Routine name")),
    Triple("search_web_answer", "Get a current, web-grounded answer (news, scores, prices, facts)", mapOf("query" to "Question")),
)

class GeminiAgent(private val prefs: Prefs, private val client: GeminiClient) {
    private val decls = JSONArray().also { arr ->
        SPECS.forEach { (n, d, p) ->
            val o = JSONObject().put("name", n).put("description", d)
            if (p.isNotEmpty()) {
                val props = JSONObject(); p.forEach { (k, v) -> props.put(k, JSONObject().put("type", "string").put("description", v)) }
                o.put("parameters", JSONObject().put("type", "object").put("properties", props))
            }
            arr.put(o)
        }
    }

    private fun system(): String = """
You are SAM, a calm, natural voice assistant running on the user's Android phone. Address the user as "Sir".
Reply in the language the user used (Hindi, English, Hinglish or any Indian language). Spoken replies: 1-2 short sentences, plain text, no markdown, unless the user asks for an explanation.
RULES: To do anything on the phone you MUST call a tool. Never say an action is done unless the tool result status is SUCCESS.
Report failures honestly: ANDROID_RESTRICTION = Android blocks it (say what was opened instead); AUTHENTICATION_REQUIRED = ask the user to unlock the phone; PERMISSION_REQUIRED = say the permission is needed.
For multi-step requests call every independent tool, continue if one fails, then give a short report using ✓ and ✗.
Ask only the minimum necessary question. Never guess which contact to call. Use search_web_answer for anything current. Use remember when asked to remember something.
For attached images/PDFs answer only from their real content. Now: ${Date()}.
User memory: ${if (prefs.memoryOn) prefs.memories().joinToString("; ").ifBlank { "none" } else "disabled"}
""".trimIndent()

    suspend fun run(text: String, att: Attachment?, history: List<Pair<String, String>>,
                    exec: suspend (ToolCall) -> ToolResult): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        history.forEach { (role, t) -> contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", t)))) }
        val up = JSONArray().put(JSONObject().put("text", text))
        att?.let { up.put(JSONObject().put("inline_data", JSONObject().put("mime_type", it.mime).put("data", it.b64))) }
        contents.put(JSONObject().put("role", "user").put("parts", up))
        repeat(6) {
            val body = JSONObject().put("contents", contents)
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
                .put("tools", JSONArray().put(JSONObject().put("function_declarations", decls)))
            val cand = client.generate(body).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return@withContext "Sir, mujhe jawab nahi mila, dobara bolein."
            if (!cand.has("role")) cand.put("role", "model")
            val parts = cand.optJSONArray("parts") ?: JSONArray()
            contents.put(cand) // kept exactly as returned (model "thought signatures" must be echoed back)
            val list = (0 until parts.length()).map { parts.getJSONObject(it) }
            val calls = list.filter { it.has("functionCall") }
            if (calls.isEmpty()) return@withContext list.mapNotNull { it.optString("text").ifBlank { null } }.joinToString(" ").trim()
            val res = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall"); val name = fc.getString("name")
                val a = fc.optJSONObject("args") ?: JSONObject()
                val r = exec(ToolCall(name, a.keys().asSequence().associateWith { a.opt(it).toString() }))
                res.put(JSONObject().put("functionResponse", JSONObject().put("name", name)
                    .put("response", JSONObject().put("status", r.status.name).put("message", r.message))))
            }
            contents.put(JSONObject().put("role", "user").put("parts", res))
        }
        "Sir, ye task bahut lamba ho gaya, thoda chhota karke bolein."
    }
}
