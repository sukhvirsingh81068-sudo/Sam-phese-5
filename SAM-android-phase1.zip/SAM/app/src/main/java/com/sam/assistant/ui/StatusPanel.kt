package com.sam.assistant.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sam.assistant.service.SamAccessibilityService
import com.sam.assistant.service.SamService

private class Item(val label: String, val ok: Boolean, val fix: Intent?)

private fun items(c: Context): List<Item> {
    val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
    fun granted(p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
    val pkg = Uri.parse("package:${c.packageName}")
    val assistant = Settings.Secure.getString(c.contentResolver, "assistant") ?: ""
    return listOf(
        Item("Microphone", granted(Manifest.permission.RECORD_AUDIO), Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)),
        Item("Notifications", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS),
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)),
        Item("Do Not Disturb access", nm.isNotificationPolicyAccessGranted, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)),
        Item("Brightness control", Settings.System.canWrite(c), Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)),
        Item("Battery optimisation off", pm.isIgnoringBatteryOptimizations(c.packageName), Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)),
        Item("Display over apps (Hey SAM screen)", Settings.canDrawOverlays(c), Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)),
        Item("Default assistant (lock-screen)", assistant.contains(c.packageName), Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)),
    )
}

@Composable
fun StatusPanel(c: Context, tick: Int, svcOn: Boolean, onToggleService: (Boolean) -> Unit) {
    @Suppress("UNUSED_VARIABLE") val t = tick // recompute after returning from Settings
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF111A38)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (svcOn) "Background: ACTIVE (notification)" else "Background: OFF", Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            Switch(svcOn, onToggleService)
        }
        items(c).forEach { i ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text((if (i.ok) "✓ " else "✗ ") + i.label, Modifier.weight(1f), color = if (i.ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A), fontSize = 13.sp)
                if (!i.ok && i.fix != null) TextButton({ c.startActivity(i.fix.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Fix") }
            }
        }
        Text("'Hey SAM' ke liye Settings mein wake switch on karein.", color = Color(0xFF8899CC), fontSize = 11.sp)
    }
}
