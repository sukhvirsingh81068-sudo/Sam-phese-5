package com.sam.assistant.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sam.assistant.automation.Automation
import com.sam.assistant.data.Prefs

private val LANGS = listOf("hi-IN" to "Hindi/Hinglish", "en-IN" to "English", "bn-IN" to "Bengali", "te-IN" to "Telugu",
    "mr-IN" to "Marathi", "ta-IN" to "Tamil", "ur-IN" to "Urdu", "gu-IN" to "Gujarati", "kn-IN" to "Kannada",
    "ml-IN" to "Malayalam", "pa-IN" to "Punjabi", "or-IN" to "Odia")
private val PERSONAS = listOf("Balanced", "Concise", "Friendly", "Professional")
private val EXAMPLES = listOf(
    "spotify kholo 8 parche song play karo aur volume 60 percent karo",
    "whatsapp kholo aur mere dost ko hii likh kar bhej do",
    "kal subah 6 baje alarm laga do",
    "Delhi ka weather batao",
    "30 minute ka timer lagao",
    "study mode routine bana do: DND on, 60 minute ka timer (Gemini)",
    "roz subah 7 baje study mode chalao (Gemini)",
    "jab battery kam ho to battery routine chalao (Gemini)")

private val SUB = Color(0xFF8899CC)
@Composable private fun Head(t: String) = Text(t, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
@Composable private fun Note(t: String) = Text(t, color = SUB, fontSize = 11.sp)
@Composable private fun Sw(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
        Switch(on, onChange)
    }
}

@Composable
fun SettingsPanel(ctx: Context, prefs: Prefs, tick: Int, onWake: (Boolean) -> Unit, onExample: (String) -> Unit) {
    var key by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var lang by remember { mutableStateOf(prefs.lang) }
    var persona by remember { mutableStateOf(prefs.persona) }
    var speed by remember { mutableStateOf(prefs.speed) }
    var wakeOn by remember(tick) { mutableStateOf(prefs.wakeOn) }
    var confirm by remember { mutableStateOf(prefs.confirmSend) }
    var privacy by remember { mutableStateOf(prefs.privacyMode) }
    var memOn by remember { mutableStateOf(prefs.memoryOn) }
    var histOn by remember { mutableStateOf(prefs.historyOn) }
    var t by remember { mutableStateOf(0) }
    val mems = remember(t) { prefs.memories() }
    val routines = remember(t) { prefs.routines().keys.toList() }
    val hist = remember(t) { prefs.history().takeLast(8).reversed() }
    val scheds = remember(t) { prefs.schedules() }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF111A38)).padding(12.dp)) {
        Head("AI brain (Gemini)")
        OutlinedTextField(key, { key = it; prefs.apiKey = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it; prefs.model = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        Text(if (prefs.apiKey.isBlank()) "Key abhi khali hai" else "✓ Key save hai (apne aap save hoti hai)", color = Color(0xFF7CFFB2), fontSize = 12.sp)

        Head("Awaaz aur andaaz")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Bhasha: " + (LANGS.firstOrNull { it.first == lang }?.second ?: lang), Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            TextButton({ lang = LANGS[(LANGS.indexOfFirst { it.first == lang } + 1).mod(LANGS.size)].first; prefs.lang = lang }) { Text("Change") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Style: $persona", Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            TextButton({ persona = PERSONAS[(PERSONAS.indexOf(persona) + 1).mod(PERSONAS.size)]; prefs.persona = persona }) { Text("Change") }
        }
        Text("Bolne ki speed: ${"%.1f".format(speed)}x", color = Color.White, fontSize = 13.sp)
        Slider(speed, { speed = it; prefs.speed = it }, valueRange = 0.6f..1.6f)

        Head("Wake word")
        Sw("'SAM' wake word (experimental)", wakeOn) { wakeOn = it; onWake(it) }
        Note("Standby mein mic on rehta hai, sirf 'SAM' shabd pakadne ke liye (SAM kuch save nahi karta). Battery zyada jati hai, beep aa sakti hai. Phone ka speech service offline pack ke bina audio Google ko bhej sakta hai.")

        Head("Safety aur privacy")
        Sw("WhatsApp bhejne se pehle poochho", confirm) { confirm = it; prefs.confirmSend = it }
        Sw("Privacy mode (memory aur history band)", privacy) { privacy = it; prefs.privacyMode = it }
        Sw("Memory", memOn) { memOn = it; prefs.memoryOn = it }
        Note("Yaadein: ${mems.size}")
        mems.takeLast(5).forEach { Note("• $it") }
        if (mems.isNotEmpty()) TextButton({ prefs.clearMemories(); t++ }) { Text("Memory saaf karein") }
        Sw("Command history", histOn) { histOn = it; prefs.historyOn = it }
        hist.forEach { Note("• $it") }
        if (hist.isNotEmpty()) TextButton({ prefs.clearHistory(); t++ }) { Text("History saaf karein") }

        Head("Routines aur automation")
        if (routines.isEmpty()) Note("Koi routine nahi. Gemini key ke baad bolein: 'study mode routine bana do: DND on aur 60 minute ka timer'")
        routines.forEach { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("• $r", Modifier.weight(1f), color = SUB, fontSize = 12.sp)
                TextButton({ prefs.deleteRoutine(r); t++ }) { Text("Delete") }
            }
        }
        Note("Roz ke schedule: " + if (scheds.isEmpty()) "koi nahi" else scheds.joinToString { "${it.first} ${it.second}:${"%02d".format(it.third)}" })
        Note("Battery low par: " + prefs.batteryRoutine.ifBlank { "koi routine nahi" })
        if (scheds.isNotEmpty() || prefs.batteryRoutine.isNotBlank())
            TextButton({ scheds.forEach { Automation.cancel(ctx, it.first, it.second, it.third) }; prefs.clearSchedules(); prefs.batteryRoutine = ""; t++ }) { Text("Automation band karein") }
        Note("Automation phone ke background mein chalti hai, isliye usme volume/DND/brightness jaise kaam rakhein, app kholne wale nahi.")

        Head("Example commands (tap karein)")
        EXAMPLES.forEach { ex ->
            Text("▶ $ex", color = Color(0xFF2FE0D0), fontSize = 12.sp, modifier = Modifier.fillMaxWidth().clickable { onExample(ex.substringBefore(" (Gemini)")) }.padding(vertical = 5.dp))
        }
    }
}
