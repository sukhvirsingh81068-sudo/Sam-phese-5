package com.sam.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sam.assistant.data.Prefs

private val LANGS = listOf("hi-IN" to "Hindi/Hinglish", "en-IN" to "English", "bn-IN" to "Bengali", "te-IN" to "Telugu",
    "mr-IN" to "Marathi", "ta-IN" to "Tamil", "ur-IN" to "Urdu", "gu-IN" to "Gujarati", "kn-IN" to "Kannada",
    "ml-IN" to "Malayalam", "pa-IN" to "Punjabi", "or-IN" to "Odia")

@Composable
fun SettingsPanel(prefs: Prefs, tick: Int, onWake: (Boolean) -> Unit) {
    var key by remember { mutableStateOf(prefs.apiKey) }
    var model by remember { mutableStateOf(prefs.model) }
    var lang by remember { mutableStateOf(prefs.lang) }
    var wakeOn by remember(tick) { mutableStateOf(prefs.wakeOn) }
    var memOn by remember { mutableStateOf(prefs.memoryOn) }
    var tick by remember { mutableStateOf(0) }
    val mems = remember(tick) { prefs.memories() }
    val routines = remember(tick) { prefs.routines().keys.toList() }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF111A38)).padding(12.dp)) {
        Text("AI brain (Gemini)", color = Color.White, fontSize = 13.sp)
        OutlinedTextField(key, { key = it; prefs.apiKey = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it; prefs.model = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        Text(if (prefs.apiKey.isBlank()) "Key abhi khali hai" else "✓ Key save hai (apne aap save hoti hai)", color = Color(0xFF7CFFB2), fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Language: " + (LANGS.firstOrNull { it.first == lang }?.second ?: lang), Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            TextButton({ lang = LANGS[(LANGS.indexOfFirst { it.first == lang } + 1).mod(LANGS.size)].first; prefs.lang = lang }) { Text("Change") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("'SAM' wake word (experimental)", Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            Switch(wakeOn, { wakeOn = it; onWake(it) })
        }
        Text("Standby mein mic on rehta hai, sirf 'SAM' shabd pakadne ke liye (SAM kuch save nahi karta). Battery zyada jati hai, beep aa sakti hai. Phone ka speech service offline pack ke bina audio Google ko bhej sakta hai.", color = Color(0xFF8899CC), fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Memory (${mems.size})", Modifier.weight(1f), color = Color.White, fontSize = 13.sp)
            Switch(memOn, { memOn = it; prefs.memoryOn = it })
        }
        mems.takeLast(5).forEach { Text("• $it", color = Color(0xFF8899CC), fontSize = 12.sp) }
        if (mems.isNotEmpty()) TextButton({ prefs.clearMemories(); tick++ }) { Text("Clear memory") }
        Text("Routines (${routines.size})", color = Color.White, fontSize = 13.sp)
        routines.forEach { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("• $r", Modifier.weight(1f), color = Color(0xFF8899CC), fontSize = 12.sp)
                TextButton({ prefs.deleteRoutine(r); tick++ }) { Text("Delete") }
            }
        }
    }
}
