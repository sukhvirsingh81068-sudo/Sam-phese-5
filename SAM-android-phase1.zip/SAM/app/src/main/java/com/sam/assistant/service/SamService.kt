package com.sam.assistant.service

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.sam.assistant.MainActivity
import com.sam.assistant.data.Prefs

/**
 * Foreground service = standby. With the wake switch ON it cycles Android's speech recognizer ONLY to spot the word "SAM"
 * at the start of an utterance. Nothing is saved by SAM. EXPERIMENTAL: not a dedicated wake-word engine, so it costs battery,
 * may beep on some phones, and the phone's speech service may use the cloud unless an offline speech pack is installed.
 */
class SamService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile private var pausedUntil = 0L
        fun start(c: Context) = c.startForegroundService(Intent(c, SamService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, SamService::class.java)) }
        fun pauseWake(ms: Long = 40000) { pausedUntil = System.currentTimeMillis() + ms }
        fun resumeWake() { pausedUntil = System.currentTimeMillis() + 1200 } // short cooldown so SAM never hears its own voice
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var wakeActive = false
    private val loop = Runnable { cycle() }

    // "SAM" (optionally preceded by hey/ok) at the START of the utterance; group 1 = whatever command follows.
    private val wakeRe = Regex("""^\s*(?:(?:hey|hay|hi|ok|okay|he)\s+)?(?:sam|saam|sem|सैम|सेम|साम)(?=$|[\s,.!?])[\s,.!?]*(.*)$""",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = Prefs(this)
        if (intent?.action == "WAKE_OFF") prefs.wakeOn = false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("sam_bg", "SAM background", NotificationManager.IMPORTANCE_LOW))
        val wake = prefs.wakeOn && hasMic()
        val open = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).putExtra("listen", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, "sam_bg")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SAM standby")
            .setContentText(if (wake) "Mic on hai, sirf 'SAM' shabd pakadne ke liye" else "Tap karke SAM se baat karein").setContentIntent(open)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).setOngoing(true)
            .addAction(0, "Talk to SAM", open)
        if (wake) b.addAction(0, "Mic band karo", PendingIntent.getForegroundService(this, 3,
            Intent(this, SamService::class.java).setAction("WAKE_OFF"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, if (wake) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else if (Build.VERSION.SDK_INT >= 30 && wake) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        stopWake()
        if (wake) { wakeActive = true; main.post(loop) }
        return START_STICKY
    }

    private fun stopWake() { wakeActive = false; main.removeCallbacks(loop); rec?.destroy(); rec = null }

    private fun cycle() {
        if (!wakeActive) return
        if (System.currentTimeMillis() < pausedUntil) { rec?.destroy(); rec = null; main.postDelayed(loop, 800); return }
        val r = rec ?: SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener); rec = it }
        try {
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true))
        } catch (e: Exception) { main.postDelayed(loop, 2000) }
    }

    private val listener = object : RecognitionListener {
        // Only FINAL results are checked, so "SAM battery kitni hai" arrives as one piece (wake word + command).
        override fun onResults(r: Bundle?) {
            val alts = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            for (t in alts) {
                val m = wakeRe.find(t) ?: continue
                onWake(m.groupValues[1].trim()); return
            }
            main.postDelayed(loop, 200)
        }
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopWake(); return }
            main.postDelayed(loop, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 250)
        }
        override fun onPartialResults(p: Bundle?) {}
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    private fun onWake(cmd: String) {
        pauseWake(60000) // the app takes over the mic; standby resumes when SAM finishes
        main.removeCallbacks(loop); rec?.destroy(); rec = null
        val i = Intent(this, MainActivity::class.java).putExtra("wake", true).putExtra("cmd", cmd)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        // Direct start works only if "Display over apps" is granted; otherwise the full-screen notification is the fallback.
        try { startActivity(i) } catch (e: Exception) { }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("sam_wake", "SAM wake", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 2, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        nm.notify(2, NotificationCompat.Builder(this, "sam_wake").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("SAM").setContentText("Tap karein").setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL).setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET).build())
        main.postDelayed({ nm.cancel(2) }, 6000)
    }

    override fun onDestroy() { stopWake(); running = false }
    override fun onBind(i: Intent?): IBinder? = null
}
