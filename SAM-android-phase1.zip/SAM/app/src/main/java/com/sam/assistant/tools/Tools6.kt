package com.sam.assistant.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.sam.assistant.automation.Automation
import com.sam.assistant.core.*
import com.sam.assistant.data.Prefs
import com.sam.assistant.service.SamAccessibilityService
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Opens a WhatsApp chat with the text pre-filled. If the user enabled SAM's Accessibility service, SAM also taps WhatsApp's
 * Send button (only within seconds of this request). Otherwise the user presses Send. Delivery can never be confirmed.
 */
class SendWhatsAppTool(private val c: Context, private val p: Prefs) : Tool {
    override val name = "send_whatsapp"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val who = args["contact"]?.replace(Regex("(?i)^(mere|meri|mera|apne|apni|my)\\s+"), "")?.trim()
        if (who.isNullOrBlank()) return ToolResult(Status.FAILED, "Kisko WhatsApp bhejna hai?")
        val text = args["text"]?.trim()
        if (text.isNullOrBlank()) return ToolResult(Status.FAILED, "Kya likhoon?")
        val f = resolveContact(c, who); f.error?.let { return it }
        if (p.confirmSend && args["confirmed"] != "yes")
            return ToolResult(Status.USER_CONFIRMATION_REQUIRED, "Sir, ${f.name} ko WhatsApp par '$text' bhej doon?")
        var num = (f.number ?: "").filter { it.isDigit() }
        if (num.startsWith("0")) num = num.drop(1)
        if (num.length == 10) num = "91$num"
        if (num.isBlank()) return ToolResult(Status.FAILED, "${f.name} ka number nahi mila")
        val svc = SamAccessibilityService.instance
        val done = CompletableDeferred<Boolean>()
        if (svc != null) { SamAccessibilityService.pending = done; SamAccessibilityService.armedUntil = System.currentTimeMillis() + 10000 }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=" + Uri.encode(text))).setPackage("com.whatsapp")
        if (!c.launch(i)) {
            SamAccessibilityService.pending = null; SamAccessibilityService.armedUntil = 0
            return ToolResult(Status.APP_NOT_INSTALLED, "WhatsApp mujhe nahi mila")
        }
        if (svc == null) return ToolResult(Status.SUCCESS, "${f.name} ke liye WhatsApp mein '$text' taiyaar hai, Send aap dabayein. ")
        val ok = withTimeoutOrNull(9000) { done.await() }
        SamAccessibilityService.pending = null; SamAccessibilityService.armedUntil = 0
        return if (ok == true) ToolResult(Status.SUCCESS, "${f.name} ko WhatsApp par '$text' ke saath Send dabaya")
        else ToolResult(Status.FAILED, "${f.name} ke liye message taiyaar hai par Send apne aap nahi dab paya, aap dabayein")
    }
}

class ScheduleRoutineTool(private val c: Context, private val p: Prefs) : Tool {
    override val name = "schedule_routine"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val n = args["name"]?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: return ToolResult(Status.FAILED, "Kaunsa routine?")
        if (!p.routines().containsKey(n)) return ToolResult(Status.FAILED, "Pehle '$n' routine banana hoga")
        val h = args["hour"]?.toIntOrNull()?.takeIf { it in 0..23 } ?: return ToolResult(Status.FAILED, "Kitne baje?")
        val m = args["minute"]?.toIntOrNull()?.takeIf { it in 0..59 } ?: 0
        p.addSchedule(n, h, m); Automation.schedule(c, n, h, m)
        return ToolResult(Status.SUCCESS, "Roz lagbhag %d:%02d par '%s' chalega (Android kuch minute late kar sakta hai)".format(h, m, n))
    }
}

class BatteryRoutineTool(private val p: Prefs) : Tool {
    override val name = "set_battery_routine"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val n = args["name"]?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: return ToolResult(Status.FAILED, "Kaunsa routine?")
        if (!p.routines().containsKey(n)) return ToolResult(Status.FAILED, "Pehle '$n' routine banana hoga")
        p.batteryRoutine = n
        return ToolResult(Status.SUCCESS, "Battery low hone par ('Low battery' warning ~15%) '$n' chalega")
    }
}
