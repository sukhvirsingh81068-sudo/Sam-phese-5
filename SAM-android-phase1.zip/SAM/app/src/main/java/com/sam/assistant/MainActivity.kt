package com.sam.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.sam.assistant.service.SamService
import com.sam.assistant.ui.*
import kotlinx.coroutines.delay

private val TEAL = Color(0xFF2FE0D0)
private val GLASS = Color(0x331E3A4A)

class MainActivity : ComponentActivity() {
    private val vm: SamViewModel by viewModels()
    private var autoListen by mutableStateOf(false)
    private var wake by mutableStateOf(false)
    private var wakeCmd by mutableStateOf("")
    private var tick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) } // shows over lock screen, does NOT unlock
        autoListen = intent?.getBooleanExtra("listen", false) == true
        wake = intent?.getBooleanExtra("wake", false) == true
        wakeCmd = intent?.getStringExtra("cmd") ?: ""
        setContent { MaterialTheme(colorScheme = darkColorScheme()) {
            SamScreen(vm, autoListen, { autoListen = false }, wake, wakeCmd, { wake = false }, tick) } }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("listen", false)) autoListen = true
        if (intent.getBooleanExtra("wake", false)) { wakeCmd = intent.getStringExtra("cmd") ?: ""; wake = true }
    }
    override fun onResume() { super.onResume(); tick++ }
}

@Composable
fun SamScreen(vm: SamViewModel, autoListen: Boolean, onAutoConsumed: () -> Unit, wake: Boolean, wakeCmd: String, onWakeConsumed: () -> Unit, tick: Int) {
    val ctx = LocalContext.current
    fun micGranted() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.listen() else vm.permissionDenied() }
    val toolPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.retry() else vm.permissionDenied("Sir, permission ke bina ye kaam nahi ho sakta.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> u?.let { vm.attach(it) } }
    var svcOn by remember { mutableStateOf(SamService.running) }
    var wakeTick by remember { mutableStateOf(0) }
    val wakeMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { vm.prefs.wakeOn = true; SamService.start(ctx); svcOn = true }
        else { vm.prefs.wakeOn = false; vm.permissionDenied("Hey SAM ke liye mic permission zaroori hai.") }
        wakeTick++ }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { SamService.start(ctx); svcOn = true }
    fun mic() { if (micGranted()) vm.listen() else perm.launch(Manifest.permission.RECORD_AUDIO) }
    fun setWake(on: Boolean) {
        if (!on) { vm.prefs.wakeOn = false; if (SamService.running) SamService.start(ctx); return }
        if (micGranted()) { vm.prefs.wakeOn = true; SamService.start(ctx); svcOn = true } else wakeMic.launch(Manifest.permission.RECORD_AUDIO)
    }
    LaunchedEffect(vm.permRequest) { vm.permRequest?.let { p -> vm.clearPerm(); toolPerm.launch(p) } }

    var input by remember { mutableStateOf("") }
    var panel by remember { mutableStateOf(0) } // 0 none, 1 status, 2 settings
    var splash by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val listState = rememberLazyListState()
    LaunchedEffect(autoListen) { if (autoListen) { onAutoConsumed(); mic() } }
    LaunchedEffect(wake) {
        if (wake) {
            val cmd = wakeCmd; onWakeConsumed(); splash = true
            delay(if (cmd.isBlank()) 1400 else 900); splash = false
            vm.wakeSession = true
            if (cmd.isBlank()) mic() else vm.submit(cmd) // "SAM" alone -> listen; "SAM <command>" -> run it directly
        }
    }
    LaunchedEffect(vm.messages.size) { if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1) }

    val locked = remember(tick) { (ctx.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked }
    val visible = if (locked) vm.messages.takeLast(1) else vm.messages.toList() // privacy: no history on lock screen

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1219), Color(0xFF123240))))
            .systemBarsPadding().imePadding().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SAM CORE INTERFACE", fontSize = 16.sp, color = Color(0xFFCFE8EC), letterSpacing = 3.sp)
            if (panel != 0) {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    TextButton({ panel = 0 }) { Text("← Wapas", color = TEAL) }
                    if (panel == 1) StatusPanel(ctx, tick, svcOn) { on ->
                        if (on) {
                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                                notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                            else { SamService.start(ctx); svcOn = true }
                        } else { SamService.stop(ctx); svcOn = false }
                    } else SettingsPanel(vm.prefs, tick + wakeTick) { setWake(it) }
                    Spacer(Modifier.height(32.dp))
                }
            } else {
                Spacer(Modifier.height(10.dp))
                SamCore(vm.state) { mic() }
                Text(when (vm.state) {
                    SamState.LISTENING -> "Listening…"
                    SamState.THINKING, SamState.EXECUTING -> "Thinking…"
                    SamState.SPEAKING -> "Speaking…"
                    SamState.ERROR -> "Error"
                    else -> if (vm.prefs.wakeOn && SamService.running) "Standby • 'SAM' bolein" else "Tap karke bolein"
                }, color = TEAL, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassCard("CORE STATUS", if (vm.state == SamState.ERROR) "ERROR" else "ONLINE", Modifier.weight(1f))
                    GlassCard("AI BRAIN", if (vm.prefs.apiKey.isBlank()) "BASIC" else "GEMINI", Modifier.weight(1f))
                    GlassCard("THOUGHT", if (vm.state == SamState.THINKING || vm.state == SamState.EXECUTING) "ACTIVE" else vm.state.name, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                    items(visible) { m ->
                        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                            Text(m.text, color = Color.White, modifier = Modifier.clip(RoundedCornerShape(14.dp))
                                .background(if (m.fromUser) Color(0xFF1E6F7A) else Color(0x551E3A4A)).padding(12.dp))
                        }
                    }
                }
                vm.attachment?.let { a ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📎 " + a.name, Modifier.weight(1f), color = TEAL, fontSize = 12.sp)
                        TextButton({ vm.dropAttachment() }) { Text("✕") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ picker.launch("*/*") }) { Text("📎") }
                    OutlinedTextField(input, { input = it }, Modifier.weight(1f).focusRequester(focus),
                        placeholder = { Text("Sam se kuch kahein…") }, singleLine = true)
                    TextButton({ if (input.isNotBlank()) { vm.submit(input); input = "" } }) { Text("Send") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NavButton("🔍", "QUERY", Modifier.weight(1f)) { panel = 0; focus.requestFocus() }
                NavButton("🗺", "MAP", Modifier.weight(1f)) { panel = 0; vm.submit("maps kholo") }
                NavButton("🌐", "STATUS", Modifier.weight(1f)) { panel = if (panel == 1) 0 else 1 }
                NavButton("⚙", "SETTINGS", Modifier.weight(1f)) { panel = if (panel == 2) 0 else 2 }
            }
        }
        if (splash) Image(painterResource(R.drawable.wake_bg), "Hey SAM", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) // wake-up screen
    }
}

@Composable
fun SamCore(state: SamState, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "core")
    val dur = when (state) { SamState.LISTENING -> 1400; SamState.THINKING, SamState.EXECUTING -> 2000; SamState.SPEAKING -> 1700; else -> 9000 }
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(dur, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(0.97f, 1.03f, infiniteRepeatable(tween(if (state == SamState.IDLE) 2600 else 700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val c1 = if (state == SamState.ERROR) Color(0xFFFF6B6B) else TEAL
    Box(Modifier.size(210.dp).scale(pulse).clip(CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2; val ctr = center
            drawCircle(Color(0xFF0F2A36), r * 0.98f)
            drawCircle(Color(0xFF4A6676), r * 0.96f, style = Stroke(3f))
            rotate(rot) { drawArc(c1, 0f, 120f, false, Offset(ctr.x - r * 0.85f, ctr.y - r * 0.85f), Size(r * 1.7f, r * 1.7f), style = Stroke(16f, cap = StrokeCap.Round)) }
            rotate(-rot * 1.4f) { drawArc(c1.copy(alpha = 0.55f), 200f, 80f, false, Offset(ctr.x - r * 0.68f, ctr.y - r * 0.68f), Size(r * 1.36f, r * 1.36f), style = Stroke(10f, cap = StrokeCap.Round)) }
            drawCircle(Color(0xFF14313F), r * 0.45f)
            drawCircle(c1.copy(alpha = 0.5f), r * 0.45f, style = Stroke(3f))
        }
        Text("S", fontSize = 60.sp, fontWeight = FontWeight.Light, color = Color(0xFFE6F4F1), fontFamily = FontFamily.Serif)
    }
}

@Composable
fun GlassCard(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(GLASS).border(1.dp, Color(0x552FE0D0), RoundedCornerShape(10.dp)).padding(8.dp)) {
        Text(label, fontSize = 9.sp, color = Color(0xFFA9C3CB), letterSpacing = 1.sp)
        Text(value, fontSize = 13.sp, color = TEAL, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun NavButton(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(GLASS).border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(12.dp))
        .clickable { onClick() }.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 20.sp)
        Text(label, fontSize = 9.sp, color = Color(0xFFCFE8EC), letterSpacing = 1.sp)
    }
}
