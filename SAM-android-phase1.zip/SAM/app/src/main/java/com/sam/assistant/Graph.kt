package com.sam.assistant

import android.app.KeyguardManager
import android.content.Context
import com.sam.assistant.ai.GeminiClient
import com.sam.assistant.core.ToolRegistry
import com.sam.assistant.data.Prefs
import com.sam.assistant.tools.*

/** One shared tool registry for the UI, background receivers and routines. */
object Graph {
    @Volatile var ignoreLock = false
    @Volatile private var reg: ToolRegistry? = null

    fun registry(ctx: Context): ToolRegistry = reg ?: synchronized(this) { reg ?: build(ctx.applicationContext).also { reg = it } }

    private fun build(c: Context): ToolRegistry {
        val p = Prefs(c); val client = GeminiClient(p)
        lateinit var r: ToolRegistry
        r = ToolRegistry(listOf(OpenAppTool(c), SetTimerTool(c), SetAlarmTool(c), BatteryTool(c), TimeTool(), DeviceInfoTool(),
            OpenSettingsTool(c), ConnectivityTool(c), WebSearchTool(c), VolumeTool(c), BrightnessTool(c), DndTool(c),
            CallTool(c), SmsTool(c), CalendarReadTool(c), CalendarCreateTool(c), WeatherTool(c), SetCityTool(c),
            PlayMusicTool(c), SendWhatsAppTool(c, p), ScheduleRoutineTool(c, p), BatteryRoutineTool(p),
            RememberTool(p), CreateRoutineTool(p), RunRoutineTool(p) { r.run(it) }, WebAnswerTool(p, client)),
            isLocked = { !ignoreLock && (c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked })
        return r
    }
}
