package com.sam.assistant.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.sam.assistant.Graph
import com.sam.assistant.core.ToolCall
import com.sam.assistant.data.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

/** Daily routines use inexact repeating alarms, so they may fire a few minutes late (Android saves battery that way). */
object Automation {
    private fun pi(c: Context, r: String, h: Int, m: Int) = PendingIntent.getBroadcast(c, "$r|$h|$m".hashCode(),
        Intent(c, AutomationReceiver::class.java).setAction("com.sam.assistant.DAILY").putExtra("routine", r),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun schedule(c: Context, routine: String, hour: Int, minute: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi(c, routine, hour, minute))
    }

    fun cancel(c: Context, routine: String, hour: Int, minute: Int) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, routine, hour, minute))
    }

    fun rescheduleAll(c: Context) { Prefs(c).schedules().forEach { schedule(c, it.first, it.second, it.third) } }
}

/** Runs the user's own saved routines on battery-low, daily schedules and after reboot. Background-safe tools only (volume, DND, brightness...). */
class AutomationReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val routine: String? = when (i.action) {
            Intent.ACTION_BATTERY_LOW -> Prefs(c).batteryRoutine.ifBlank { null }
            "com.sam.assistant.DAILY" -> i.getStringExtra("routine")
            Intent.ACTION_BOOT_COMPLETED -> { Automation.rescheduleAll(c); null }
            else -> null
        }
        if (routine == null) return
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                Graph.ignoreLock = true // the user set this automation up themselves; protected tools may run while locked
                Graph.registry(c).run(ToolCall("run_routine", mapOf("name" to routine)))
            } finally { Graph.ignoreLock = false; pr.finish() }
        }
    }
}
