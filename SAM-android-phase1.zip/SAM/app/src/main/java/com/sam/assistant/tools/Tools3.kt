package com.sam.assistant.tools

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.sam.assistant.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

internal fun Context.has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
internal class Found(val name: String?, val number: String?, val error: ToolResult?)

/** Never guesses: several different matches -> asks the user. */
internal fun resolveContact(c: Context, query: String?): Found {
    if (query.isNullOrBlank()) return Found(null, null, ToolResult(Status.FAILED, "Kiska naam?"))
    if (!c.has(Manifest.permission.READ_CONTACTS))
        return Found(null, null, ToolResult(Status.PERMISSION_REQUIRED, "Contacts dekhne ke liye permission chahiye", Manifest.permission.READ_CONTACTS))
    val found = linkedMapOf<String, String>()
    c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$query%"), null)?.use {
        while (it.moveToNext()) found.putIfAbsent(it.getString(0), it.getString(1))
    }
    if (found.isEmpty()) return Found(null, null, ToolResult(Status.FAILED, "$query naam ka contact nahi mila"))
    val exact = found.keys.firstOrNull { it.equals(query, true) }
    if (found.size > 1 && exact == null)
        return Found(null, null, ToolResult(Status.USER_CONFIRMATION_REQUIRED,
            found.keys.take(3).joinToString(" ya ") + "? Poora naam bolkar dobara kahein"))
    val n = exact ?: found.keys.first()
    return Found(n, found[n], null)
}

/** Opens the dialer with the number filled in; the user presses the call button (safer than auto-calling). */
class CallTool(private val c: Context) : Tool {
    override val name = "make_call"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val f = args["number"]?.let { Found(it, it, null) } ?: resolveContact(c, args["contact"])
        f.error?.let { return if (args["contact"] == null && args["number"] == null) ToolResult(Status.FAILED, "Kisko call karoon?") else it }
        return if (c.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(f.number)))))
            ToolResult(Status.SUCCESS, "${f.name} ka number dialer mein khol diya, call button dabayein")
        else ToolResult(Status.FAILED, "Dialer open nahi hua")
    }
}

/** Creates a draft in the messaging app; the user presses Send. */
class SmsTool(private val c: Context) : Tool {
    override val name = "send_message"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        if (args["contact"] == null) return ToolResult(Status.FAILED, "Kisko message bhejna hai?")
        val f = resolveContact(c, args["contact"]); f.error?.let { return it }
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(f.number))).putExtra("sms_body", args["text"] ?: "")
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "${f.name} ke liye message draft taiyaar hai, Send aap dabayenge")
        else ToolResult(Status.FAILED, "Messaging app open nahi hua")
    }
}

class CalendarReadTool(private val c: Context) : Tool {
    override val name = "get_calendar_events"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        if (!c.has(Manifest.permission.READ_CALENDAR))
            return ToolResult(Status.PERMISSION_REQUIRED, "Calendar dekhne ke liye permission chahiye", Manifest.permission.READ_CALENDAR)
        val day = args["day"]?.toIntOrNull() ?: 0
        val start = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, day); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
        val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start.timeInMillis); ContentUris.appendId(b, end.timeInMillis)
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault()); val list = mutableListOf<String>()
        c.contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), null, null,
            CalendarContract.Instances.BEGIN + " ASC")?.use { while (it.moveToNext()) list += "${fmt.format(Date(it.getLong(1)))} ${it.getString(0)}" }
        val label = if (day == 0) "Aaj" else "Kal"
        return ToolResult(Status.SUCCESS, if (list.isEmpty()) "$label koi event nahi hai" else "$label ke events: " + list.joinToString("; "))
    }
}

/** Opens the calendar's pre-filled event form; the user presses Save. */
class CalendarCreateTool(private val c: Context) : Tool {
    override val name = "create_calendar_event"
    override val requiresUnlock = true
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, args["day"]?.toIntOrNull() ?: 0)
            set(Calendar.HOUR_OF_DAY, args["hour"]?.toIntOrNull() ?: return ToolResult(Status.FAILED, "Kitne baje?"))
            set(Calendar.MINUTE, args["minute"]?.toIntOrNull() ?: 0); set(Calendar.SECOND, 0) }
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, args["title"] ?: "Event")
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + 3600_000)
        return if (c.launch(i)) ToolResult(Status.SUCCESS, "Event form khul gaya hai, Save aap dabayenge")
        else ToolResult(Status.FAILED, "Calendar app open nahi hua")
    }
}

class SetCityTool(private val c: Context) : Tool {
    override val name = "set_city"
    override suspend fun execute(args: Map<String, String>): ToolResult {
        val city = args["city"] ?: return ToolResult(Status.FAILED, "Kaunsa shehar?")
        c.getSharedPreferences("sam", Context.MODE_PRIVATE).edit().putString("city", city).apply()
        return ToolResult(Status.SUCCESS, "Aapka shehar $city yaad rakh liya")
    }
}

/** Real data from Open-Meteo (free, no API key). */
class WeatherTool(private val c: Context) : Tool {
    override val name = "get_weather"
    private fun desc(code: Int) = when (code) {
        0 -> "saaf aasman"; 1, 2, 3 -> "baadal"; 45, 48 -> "kohra"
        in 51..67 -> "baarish"; in 71..77 -> "barf"; in 80..82 -> "baarish ki bauchaar"; in 95..99 -> "toofan"; else -> "mausam mila-jula"
    }
    private fun get(url: String): JSONObject {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 8000; con.readTimeout = 8000
        return try { JSONObject(con.inputStream.bufferedReader().readText()) } finally { con.disconnect() }
    }
    override suspend fun execute(args: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val city = args["city"] ?: c.getSharedPreferences("sam", Context.MODE_PRIVATE).getString("city", null)
            ?: return@withContext ToolResult(Status.FAILED, "Kaunsa shehar? Bol dein: 'mera shehar Delhi hai'")
        val day = (args["day"]?.toIntOrNull() ?: 0).coerceIn(0, 1)
        try {
            val g = get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + Uri.encode(city)).optJSONArray("results")
                ?.optJSONObject(0) ?: return@withContext ToolResult(Status.FAILED, "$city shehar nahi mila")
            val w = get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}&longitude=${g.getDouble("longitude")}" +
                "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=2")
            val d = w.getJSONObject("daily"); val cur = w.getJSONObject("current")
            val tail = "max ${Math.round(d.getJSONArray("temperature_2m_max").getDouble(day))}°, min ${Math.round(d.getJSONArray("temperature_2m_min").getDouble(day))}°, " +
                "baarish ki sambhavna ${d.getJSONArray("precipitation_probability_max").optInt(day)}%"
            ToolResult(Status.SUCCESS, if (day == 0)
                "${g.getString("name")} mein abhi ${Math.round(cur.getDouble("temperature_2m"))}°C, ${desc(cur.getInt("weather_code"))}, humidity ${cur.getInt("relative_humidity_2m")}%. Aaj $tail"
            else "${g.getString("name")} mein kal ${desc(d.getJSONArray("weather_code").getInt(day))}, $tail")
        } catch (e: java.io.IOException) { ToolResult(Status.NETWORK_ERROR, "Internet response nahi aa raha, thodi der baad try karein") }
    }
}
