package com.sam.assistant.tools

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import com.sam.assistant.core.*

/**
 * Plays/searches music in a music app. Android gives no way to confirm that a song actually started,
 * so the result says honestly what was opened.
 */
class PlayMusicTool(private val c: Context) : Tool {
    override val name = "play_music"
    private val apps = linkedMapOf(
        "spotify" to "com.spotify.music",
        "youtube music" to "com.google.android.apps.youtube.music",
        "ytmusic" to "com.google.android.apps.youtube.music",
        "youtube" to "com.google.android.youtube",
        "jiosaavn" to "com.jio.media.jiobeats",
        "wynk" to "com.bsbportal.music")

    private fun installed(pkg: String) = c.packageManager.getLaunchIntentForPackage(pkg) != null

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val q = args["query"]?.takeIf { it.isNotBlank() } ?: return ToolResult(Status.FAILED, "Kaunsa gaana chalaoon?")
        val want = args["app"]?.lowercase()?.trim()
        val label = want?.takeIf { apps.containsKey(it) }
            ?: apps.keys.firstOrNull { apps[it]?.let(::installed) == true }
            ?: return ToolResult(Status.APP_NOT_INSTALLED, "Koi music app (Spotify/YouTube Music) mujhe nahi mila")
        val pkg = apps.getValue(label)
        if (!installed(pkg)) return ToolResult(Status.APP_NOT_INSTALLED, "$label app installed nahi hai")
        // 1) ask the app to play from a search; 2) fall back to opening its search screen
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).setPackage(pkg)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*").putExtra(SearchManager.QUERY, q)
        if (c.launch(play)) return ToolResult(Status.SUCCESS, "$label mein '$q' chalane ki request bheji. Na bajey to gaane par tap karein")
        val search = if (label == "spotify") Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(q)))
            else Intent(Intent.ACTION_SEARCH).setPackage(pkg).putExtra(SearchManager.QUERY, q)
        return if (c.launch(search)) ToolResult(Status.SUCCESS, "$label mein '$q' ka search khol diya. Gaane par tap karke chalayein")
        else ToolResult(Status.FAILED, "$label mein '$q' nahi chala paya")
    }
}
