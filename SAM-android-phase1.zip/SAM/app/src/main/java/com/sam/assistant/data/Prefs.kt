package com.sam.assistant.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local-only settings. The Gemini key is the user's own, typed into the app; it is never bundled in the APK. */
class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("sam", Context.MODE_PRIVATE)
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    var apiKey: String get() = s("apiKey", ""); set(v) { sp.edit().putString("apiKey", v).apply() }
    var model: String get() = s("model", "gemini-3.5-flash"); set(v) { sp.edit().putString("model", v).apply() }
    var lang: String get() = s("lang", "hi-IN"); set(v) { sp.edit().putString("lang", v).apply() }
    var wakeOn: Boolean get() = sp.getBoolean("wakeOn", false); set(v) { sp.edit().putBoolean("wakeOn", v).apply() }
    var speed: Float get() = sp.getFloat("speed", 1.0f); set(v) { sp.edit().putFloat("speed", v).apply() }
    var persona: String get() = s("persona", "Balanced"); set(v) { sp.edit().putString("persona", v).apply() }
    var confirmSend: Boolean get() = sp.getBoolean("confirmSend", false); set(v) { sp.edit().putBoolean("confirmSend", v).apply() }
    var privacyMode: Boolean get() = sp.getBoolean("privacy", false); set(v) { sp.edit().putBoolean("privacy", v).apply() }
    var historyOn: Boolean get() = sp.getBoolean("histOn", true); set(v) { sp.edit().putBoolean("histOn", v).apply() }
    var batteryRoutine: String get() = s("batRoutine", ""); set(v) { sp.edit().putString("batRoutine", v).apply() }
    fun history(): List<String> = JSONArray(s("hist", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addHistory(e: String) { sp.edit().putString("hist", JSONArray((history() + e).takeLast(100)).toString()).apply() }
    fun clearHistory() { sp.edit().remove("hist").apply() }
    /** daily schedules stored as "routine|hour|minute" */
    fun schedules(): List<Triple<String, Int, Int>> = JSONArray(s("sched", "[]")).let { a ->
        (0 until a.length()).mapNotNull { i -> a.getString(i).split("|").let { p -> if (p.size == 3) Triple(p[0], p[1].toInt(), p[2].toInt()) else null } } }
    fun addSchedule(r: String, h: Int, m: Int) {
        val l = schedules().filterNot { it.first == r && it.second == h && it.third == m } + Triple(r, h, m)
        sp.edit().putString("sched", JSONArray(l.map { "${it.first}|${it.second}|${it.third}" }).toString()).apply()
    }
    fun clearSchedules() { sp.edit().remove("sched").apply() }
    var memoryOn: Boolean get() = sp.getBoolean("memOn", true); set(v) { sp.edit().putBoolean("memOn", v).apply() }

    fun memories(): List<String> = JSONArray(s("mem", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addMemory(f: String) { sp.edit().putString("mem", JSONArray((memories() + f).takeLast(50)).toString()).apply() }
    fun clearMemories() { sp.edit().remove("mem").apply() }

    /** routine name (lowercase) -> JSON array of {"tool":..., "args":{...}} */
    fun routines(): Map<String, String> = JSONObject(s("routines", "{}")).let { o -> o.keys().asSequence().associateWith { o.getString(it) } }
    fun saveRoutine(name: String, steps: String) {
        val o = JSONObject(s("routines", "{}")); o.put(name.lowercase().trim(), steps)
        sp.edit().putString("routines", o.toString()).apply()
    }
    fun deleteRoutine(name: String) {
        val o = JSONObject(s("routines", "{}")); o.remove(name)
        sp.edit().putString("routines", o.toString()).apply()
    }
}
