package com.sam.assistant.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech in/out. Retries on busy/unsupported-language/broken default service and explains every failure in plain words. */
class VoiceEngine(private val c: Context, private val speed: () -> Float,
                  private val onText: (String) -> Unit, private val onFail: (String) -> Unit, private val onSpeechDone: () -> Unit,
                  private val onRms: (Float) -> Unit, private val onPartial: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val tts: TextToSpeech = TextToSpeech(c) { ttsReady = it == TextToSpeech.SUCCESS }.also { t ->
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(onSpeechDone) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post(onSpeechDone) }
        })
    }

    private fun errorText(e: Int) = when (e) {
        3 -> "Mic se awaaz nahi mil rahi. Koi aur app mic use kar rahi ho sakti hai, use band karke dobara try karein."
        9 -> "Mic permission nahi hai. Phone Settings > Apps > SAM > Permissions mein Microphone allow karein."
        1, 2, 4, 11 -> "Speech service tak nahi pahunch paya. Internet check karein ya Google ka offline speech pack download karein."
        6 -> "Kuch suna nahi. Mic dabakar turant bolein."
        7 -> "Samajh nahi aaya. Thoda paas se aur saaf bolein."
        8 -> "Speech service busy hai, thodi der baad try karein."
        5 -> "Speech service chal nahi rahi. Google app update karein aur phone restart karke dekhein."
        10 -> "Bahut zyada requests, thodi der ruk kar try karein."
        12, 13 -> "Ye bhasha speech service mein available nahi hai. Settings mein English chunein."
        else -> "Mic mein dikkat aayi (code $e)."
    }

    fun startListening(lang: String = "hi-IN", attempt: Int = 0, google: Boolean = false) {
        tts.stop()
        if (!google && !SpeechRecognizer.isRecognitionAvailable(c)) { startListening(lang, attempt, true); return }
        recognizer?.destroy()
        val r = try {
            if (google) SpeechRecognizer.createSpeechRecognizer(c, ComponentName("com.google.android.googlequicksearchbox",
                "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"))
            else SpeechRecognizer.createSpeechRecognizer(c)
        } catch (e: Exception) { onFail("Speech service nahi mili. Google app install/update karein."); return }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                onRms(0f)
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onFail(errorText(7)) else onText(t)
            }
            override fun onError(error: Int) {
                onRms(0f)
                when {
                    error == 8 && attempt < 2 -> main.postDelayed({ startListening(lang, attempt + 1, google) }, 700)
                    (error == 12 || error == 13) && lang != "en-IN" -> startListening("en-IN", attempt + 1, google)
                    (error == 5 || error == 3 || error == 4) && !google && attempt < 2 -> startListening(lang, attempt + 1, true)
                    else -> onFail(errorText(error))
                }
            }
            override fun onRmsChanged(v: Float) { onRms(((v + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onPartialResults(p: Bundle?) {
                p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { if (it.isNotBlank()) onPartial(it) }
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, c.packageName)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L))
        recognizer = r
    }

    fun speak(text: String, tag: String) {
        if (!ttsReady) { onSpeechDone(); return }
        tts.language = Locale.forLanguageTag(tag)
        tts.setSpeechRate(speed().coerceIn(0.5f, 2f))
        tts.speak(text.replace("✓", "").replace("✗", "").replace("⏳", ""), TextToSpeech.QUEUE_FLUSH, null, "sam")
    }

    fun stop() { tts.stop(); recognizer?.cancel() }
    fun release() { recognizer?.destroy(); tts.shutdown() }
}
