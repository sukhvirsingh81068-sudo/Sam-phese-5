package com.sam.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class VoiceEngine(private val c: Context, private val onText: (String) -> Unit,
                  private val onFail: (String) -> Unit, private val onSpeechDone: () -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private val tts: TextToSpeech = TextToSpeech(c) { ttsReady = it == TextToSpeech.SUCCESS }.also { t ->
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(onSpeechDone) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post(onSpeechDone) }
        })
    }

    fun startListening(lang: String = "hi-IN") {
        if (!SpeechRecognizer.isRecognitionAvailable(c)) { onFail("Speech recognition is device par available nahi hai"); return }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(c)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onFail("Awaaz samajh nahi aayi") else onText(t)
            }
            override fun onError(error: Int) { onFail("Awaaz suni nahi gayi, dobara try karein") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L))
        recognizer = r
    }

    fun speak(text: String, tag: String) {
        if (!ttsReady) { onSpeechDone(); return }
        tts.language = Locale.forLanguageTag(tag)
        tts.speak(text.replace("✓", "").replace("✗", ""), TextToSpeech.QUEUE_FLUSH, null, "sam")
    }

    fun stop() { tts.stop(); recognizer?.cancel() }
    fun release() { recognizer?.destroy(); tts.shutdown() }
}
