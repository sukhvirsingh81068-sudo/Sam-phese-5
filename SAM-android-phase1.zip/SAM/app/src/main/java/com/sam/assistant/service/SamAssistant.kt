package com.sam.assistant.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import com.sam.assistant.MainActivity

/** Lets the user pick SAM as the default digital assistant (power-button / home-hold, also from the lock screen). */
class SamInteractionService : VoiceInteractionService()

class SamSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = SamSession(this)
}

class SamSession(c: Context) : VoiceInteractionSession(c) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        startAssistantActivity(Intent(context, MainActivity::class.java).putExtra("listen", true))
        finish()
    }
}
