# SAM — Phase 1 (Core)
Open in Android Studio (Koala+), sync (generates the Gradle wrapper), run on a real phone (mic needs one).

## IMPLEMENTED
- Compose UI: animated orb (idle/listening/thinking/executing/speaking/error), chat, mic + text input
- Voice in (SpeechRecognizer, hi-IN) and out (TextToSpeech, Hindi/English)
- Tool architecture: ToolResult statuses + ToolRegistry (brain never touches Android)
- Tools: open_app, set_timer, set_alarm (system Clock app), battery, time, device info, open_settings, web search (browser)
- Multi-step commands ("... aur ...", ","); report shows ✓/✗ only from real tool results
- Wi-Fi/Bluetooth on/off returns ANDROID_RESTRICTION and opens settings (Android 10+ blocks direct toggle)

## REQUIRES ANDROID/API INTEGRATION (Phase 2-3)
- LLM Brain: implement `Brain` against your own secure backend (never ship API keys in the APK)
- Foreground service + wake word (e.g. Porcupine); lock-screen via assistant role (VoiceInteractionService)
- Volume, DND (notification-policy access), brightness (WRITE_SETTINGS), calls, SMS, calendar, weather

## FUTURE
- Memory, routines/automation, smart home, 22-language support, provider switching

Notes: RuleBasedBrain is a simple offline parser, not real AI understanding. "kal" vs "aaj" for alarms isn't distinguished (Clock app sets next occurrence). Not compiled here (no network in sandbox), so expect minor fixes on first sync.

---
# PHASE 2 (added)
IMPLEMENTED: volume (media/alarm/ring/notification, read-back verified), brightness (needs "Modify system settings"),
Do Not Disturb (needs DND access), Wi-Fi (direct only on Android 9-; Android 10+ opens system Wi-Fi panel),
Bluetooth (settings only), foreground service + notification, status/permission dashboard with Fix buttons,
lock-screen: SAM can show over lock screen; protected tools (apps, settings, brightness, DND, Wi-Fi, web) return
AUTHENTICATION_REQUIRED while locked; safe ones (battery, time, timer, alarm, volume) still work.
Assistant role: SAM is selectable as default assistant (Settings > Default apps > Digital assistant).
NOT YET: wake word ("Hey SAM") — needs a wake-word engine; background mic listening; chat history is still visible on lock screen.
RISKS: not compiled here; the assistant-role service and alarm-from-lockscreen behave differently across OEMs.

---
# PHASE 3 (added)
IMPLEMENTED: contact lookup (asks when several match), call -> opens dialer with number (user presses Call),
SMS -> opens draft in messaging app (user presses Send), calendar: read today/tomorrow events, create event
(opens pre-filled form, user presses Save), reminders (Clock app alarm with label), weather via Open-Meteo
(today/tomorrow, "kal?" follow-up works, remembers city), runtime permission prompt + auto-retry.
Also FIXED: app launching of Clock/Settings/browser intents on Android 11+.
NOT YET (needs the LLM brain, Phase 3b): file search/management, image understanding, PDF/document AI,
real web search with summaries (currently opens browser), natural conversation.
LIMITS: "kal" for reminders/alarms sets next occurrence only; contact picks need full name after ambiguity prompt.

---
# PHASE 4+ (added)
IMPLEMENTED: Gemini agent loop (user's own API key typed in app; model name editable; function calling -> app executes tools -> real
result goes back to the model), Google-Search-grounded answers, image/PDF/text understanding via the attach button (inline, <=15MB),
memory (view/clear/disable), custom commands & routines ("study mode" runs saved steps, works offline), Indian-language speech
selection (12 languages in-app; actual quality depends on the phone's speech engine and Gemini), lock-screen chat privacy,
automatic fallback to the offline rule-based brain if no key / no internet.
NOT IMPLEMENTED: "Hey SAM" wake word (needs a wake-word engine + key), time/event automation (e.g. battery<20%),
smart home, file manager (move/rename/delete), accessibility UI control, backend proxy for API key (key is stored on-device only).

---
# WAKE WORD + NEW LOOK (added)
- App icon = lens tile image; wake-up screen = "Initialize SAM" image (shown for ~1.7s when "Hey SAM" is heard, then SAM listens);
  main screen restyled as "SAM CORE INTERFACE" (animated core ring, status cards, QUERY/MAP/STATUS/SETTINGS buttons).
- "Hey SAM": Settings -> switch on. EXPERIMENTAL: uses Android SpeechRecognizer in a microphone foreground service
  (not a dedicated wake-word engine): more battery, possible beeps, can miss/false-trigger. To open the screen from background
  grant "Display over other apps" (Status panel -> Fix); otherwise a full-screen notification appears.

---
# SIRI-STYLE FLOW (updated)
Standby (only if switch ON + mic permission) -> hears "SAM" at start of utterance -> wake screen -> listening -> Gemini ->
speaks -> standby. "SAM <command>" runs the command directly. "SAM" alone with no command -> quietly back to standby.
Screen labels: Listening… / Thinking… / Speaking… / Standby. Notification has "Mic band karo" to stop standby instantly.
